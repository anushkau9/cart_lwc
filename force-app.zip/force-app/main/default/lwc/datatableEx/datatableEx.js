import {
    LightningElement,
    api,
    wire,
    track
} from 'lwc';
import getProduct from '@salesforce/apex/GetAllProducts.getProduct';

    

export default class ComboboxEx extends LightningElement {
    @track products;
    @track error;
    @track
    statusOptions = [{
            value: 'Product2',
            label: 'Product2'
        },
        {
            value: 'Account',
            label: 'Account'
        },
        {
            value: 'Opportunity',
            label: 'Opportunity'
        },
        {
            value: 'Contact',
            label: 'Contact'
        },
        
    ];
    @track value = '';
    handleChange(event) {
      const select = event.detail.value;
        getProduct({
                family: select
            })
            .then(result => {
                this.products = result;
                this.error = undefined;
            })
            .catch(error => {
                this.error = error;
                this.products = undefined;
            });
 
        
    }
    
    }
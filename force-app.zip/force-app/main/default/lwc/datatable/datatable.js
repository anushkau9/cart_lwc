import { LightningElement,wire,track } from 'lwc';  
 import {refreshApex} from '@salesforce/apex';  
 import getAllProd from '@salesforce/apex/productList.fetchProductList';  
 import deleteProduct from '@salesforce/apex/productList.deleteProduct';  
 const COLS=[  
   {label:'Name',fieldName:'Name', type:'text'},  
   {label:'Family',fieldName:'Family', type:'text'},  
   {label:'Description',fieldName:'Description', type:'Text'}  
 ];  
 export default class DataTableInLwc extends LightningElement {  
   cols=COLS;  
   @wire(getAllProd) prodList;  
   deleteRecord(){  
     var selectedRecords =  
      this.template.querySelector("lightning-datatable").getSelectedRows();  
     deleteOpportunities({oppList: selectedRecords})  
     .then(result=>{  
       return refreshApex(this.prodList);  
     })  
     .catch(error=>{  
       alert('Cloud not delete'+JSON.stringify(error));  
     })  
   }  
 }  